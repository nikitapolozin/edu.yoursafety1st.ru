<?php
/**
* Smarty plugin: test function
*/
function smarty_function_test($params, &$smarty) {
    
    return 'aaa';
}

?>