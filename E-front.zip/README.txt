eFront Readme
-------------
Welcome to our community!

In a few words, eFront is an easy to use, visually attractive, SCORM compatible, eLearning and Human Capital Management platform. 

Easy to use: eFront was build from the scratch with the end user in mind. You will find it rather natural to get used to its interface where most options are self-explenatory.

Visually attractive: We didn't want to build another eLearning tool. We aim at building the most beautiful eLearning tool. 

Technologically advanced: eFront is an Ajax enabled, Unicode, LDAP and SCORM supporting, multilingual eLearning platform.

Pedagogical concepts: Integrated to eFront are sound pedagogical concepts that guide users and keep them motivated.

Open Source: eFront is offered as an open source software. Download it for free, customize it to your needs, add new functionalites and share them with the community. Although distributed as free software, eFront is being supported by a professional team of highly skilled developers.

Complete: eFront includes a wide variety of components that help you create your lesson structure and add content, build online-tests, communicate with others, track users history and progress,  conduct surveys,  assign projects, and create certifications. And this list just scratches the surface of the system.

Visit us for more info and platform updates at:
http://www.efrontlearning.net
