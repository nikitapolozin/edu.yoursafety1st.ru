<?php
define("_MODULE_ADMINISTRATOR_TOOLS","ابزار مدیر");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","نام جدید ورود به سایت");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","کاربر را انتخاب کنید برای ورود به سایت تغییر برای");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","ورود به سایت تغییر");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","کاربر با این ورود به سایت در حال حاضر وجود دارد");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","عملیات با موفقیت تمام شد اما جدول زیر نمی تواند به روز شده");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","تنظیمات درس جهانی");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","رابط گذاشتن");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","دستور گذاشتن");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","سطرها در مجموعه");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","پرس و جو خوب");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","ردیف تحت تاثیر قرار");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","مجموعه تهی");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","فله کامل درس ها و دوره");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","البته درس تنظیم کاربران");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","دوره های Unenroll");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","نوع نهاد");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","ورود به نهاد");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","انتخاب ورود");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","انتخاب نوع انتساب");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","کاربران Unenroll");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","این عملیات به همه کاربران است که بخشی از این نهاد از همه دوره های خود را unenroll. آیا مطمئن هستید؟");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","رده گزارش");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","انتخاب گروه :");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","دوره نمایش ناقص");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","کامل از");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","تکمیل شده را به");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","دوره ها غیر فعال");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","ورود تاریخی");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","کاربر بیکار");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","تاریخ و زمان آخرین اقدام");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","نمایش کاربران غیر فعال از سال");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","آرشیو تمام کاربران");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","این آرشیو به تمام کاربران بازگردانده مطابق معیارهای انتخاب نشده است! آیا مطمئن هستید؟");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","غیر فعال کردن همه کاربران");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","این کار باعث غیر فعال کردن همه کاربران بازگردانده مطابق معیارهای انتخاب نشده است! آیا مطمئن هستید؟");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","وضعیت تعویض");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","تاریخ و زمان آخرین 3 ماه");//Last 3 months
?>