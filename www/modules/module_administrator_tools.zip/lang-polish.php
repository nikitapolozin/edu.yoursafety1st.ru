<?php
define("_MODULE_ADMINISTRATOR_TOOLS","narzędzia Administrator");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Nowy login");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Wybierz użytkownika, aby zmienić login");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","logowanie Zmień");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Użytkownik o tej już istnieje");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operacja zakończona pomyślnie, ale poniższe tabele nie mogą być aktualizowane");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Globalne ustawienia lekcji");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","interfejs SQL");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","polecenia SQL");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Wiersze w komplecie");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","wierszy");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Empty set");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Bulk pełne lekcje i kursy");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Oczywiście użytkownicy Set lekcji");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","kursy Unenroll");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Typ Podmiotu");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Jednostki wejścia");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Wybierz hasło");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Wybierz typ zadania");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","użytkowników Unenroll");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Operacja ta unenroll wszystkich użytkowników, które są częścią tego podmiotu ze wszystkich swoich kursów. Czy na pewno?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategoria raportów");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Wybierz kategorię");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Pokaż kursy niekompletne");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Zrealizowane z");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","zakończone");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Pokaż nieaktywne kursy");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","wejścia Historic");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","użytkowników Idle");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Ostatnia akcja");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Pokazuj od bezczynności");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Archiwum wszystkich użytkowników");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","To archiwum wszystkich użytkowników zwróciło pasujących do wybranych kryteriów! Czy na pewno?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Wyłączenie wszystkich użytkowników");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Spowoduje to wyłączenie wszystkich użytkowników zwróciło pasujących do wybranych kryteriów! Czy na pewno?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","status Toggle");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Ostatnie 3 miesiące");//Last 3 months
?>