<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Адміністратор інструменти");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Нові Логін ім&#39;я");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Виберіть користувачеві змінювати Логін для");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Зміна Увійти");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Користувач з таким Логін вже існує");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Операція виконана успішно, але наступні таблиці не може бути оновлена");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Загальні параметри урок");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL інтерфейс");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL команди");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Рядки в комплекті");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Запит OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","рядків");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Порожня множина");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Масова повної уроки та курси");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Встановити користувачів курс Урок");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll курси");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Тип сутності");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entity вступу");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Виберіть запис");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Виберіть завдання типу");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll користувачів");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Ця операція буде unenroll всіх користувачів, які є частиною даної особи від всіх своїх курсів. Ви впевнені?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Категорія доповіді");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Вибір категорії");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Показати Неповні курси");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Виконаний з");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","завершено до");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Показувати неактивні курси");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Історичний вступу");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Очікування користувачів");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Останні дії");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Показати користувачів простою із");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Архів всіх користувачів");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Це архів всіх користувачів повернувся відповідають вибраним критеріям! Ви впевнені?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Відключення всіх користувачів");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Це призведе до відключення всіх користувачів повернувся відповідають вибраним критеріям! Ви впевнені?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Перемикання статусу");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Останні 3 місяці");//Last 3 months
?>