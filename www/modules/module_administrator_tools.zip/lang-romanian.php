<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrator unelte");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Nou login nume");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","utilizator Selectaţi pentru a schimba de conectare pentru");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Schimbarea autentificare");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Un utilizator cu acest nume există deja");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operaţiunea a finalizat cu succes, dar tabelele de mai jos nu a putut fi actualizat");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Setări globale lecţie");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL interfaţă");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL comandă");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Rânduri în set");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","rândurile afectate");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Gol set");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Vrac complete lecţii şi cursuri");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Set lecţie curs de utilizatori");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll cursuri");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Entitate de tip");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entitate de intrare");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Selectaţi o intrare");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Selectaţi un tip de cesiune");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll utilizatori");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Această operaţiune va unenroll toţi utilizatorii care fac parte din această entitate de la toate cursurile sale. Esti sigur?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Categorie rapoarte");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Selectati categoria");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Arată cursuri incomplete");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Completat de la");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","completat pentru a");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Arată cursuri inactive");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Istoric de intrare");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Idle utilizatori");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Ultima acţiune");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Afişaţi utilizatorii inactiv, deoarece");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arhiva toţi utilizatorii");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Această arhivă va tuturor utilizatorilor returnate corespund criteriilor selectate! Esti sigur?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Dezactiva toţi utilizatorii");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Aceasta va dezactiva toţi utilizatorii returnate corespund criteriilor selectate! Esti sigur?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Comuta starea");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Ultimele 3 luni");//Last 3 months
?>