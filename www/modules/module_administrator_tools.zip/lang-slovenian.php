<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrator orodja");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Novo ime za prijavo");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Izberite uporabnika, da spremenite podatke za prijavo");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Spremeni prijavo");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Uporabnik s tem imenom že obstaja");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operacija uspešno zaključena, vendar naslednje tabele ni bilo mogoče posodobiti");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Globalne nastavitve lekcije");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL vmesnik");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL ukaz");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Vrstice v kompletu");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","prizadetih vrstic");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Prazne iz");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Bulk popolne izkušnje in tečaji");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Set tečaj lekcijo uporabnikov");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Izpisati tečaji");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Vrsta objekta");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Podjetje vpis");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Izberite vnos");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Izberite vrsto odstop");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Izpisati uporabnikov");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","V ta namen bo izpisati vse uporabnike, ki so del te entitete iz vseh njegovih tečajev. Ali ste prepričani?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategorija poročil");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Izberite kategorijo");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Prikaži Nepopolna tečaji");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Opravljene od");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","zaključena");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Prikaži neaktivne tečaji");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Zgodovinski vpis");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Idle uporabnikov");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Zadnje dejanje");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Prikaži uporabnikov idle saj");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arhiv vseh uporabnikov");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","To se bo arhiv vseh uporabnikov vrnil ustrezajo izbrane kriterije! Ali ste prepričani?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Izključi vse uporabnike");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","To izključi vse uporabnike vrnil ustrezajo izbrane kriterije! Ali ste prepričani?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Toggle status");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Zadnjih 3 mesecih");//Last 3 months
?>