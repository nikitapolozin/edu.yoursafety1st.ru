<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrator alat");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Baru nama login");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Pilih pengguna untuk mengubah login untuk");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Mengubah login");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Seorang pengguna dengan login ini sudah ada");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operasi berhasil diselesaikan namun tabel berikut ini tidak dapat diperbarui");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Global pelajaran pengaturan");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL antarmuka");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","Perintah SQL");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Rows in set");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","baris terpengaruh");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Kosong set");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Bulk menyelesaikan pelajaran dan program");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","kursus pelajaran Set pengguna");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll program");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Jenis Entitas");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entitas entri");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Pilih entri");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Pilih jenis tugas");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll pengguna");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Operasi ini akan unenroll semua pengguna yang merupakan bagian dari entitas dari semua program tersebut. Apakah Anda yakin?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategori laporan");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Pilih kategori");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Tampilkan lengkap program");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Selesai dari");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","selesai");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Tampilkan aktif program");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Entri Bersejarah");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Idle pengguna");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Tindakan terakhir");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Tampilkan pengguna menganggur sejak");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arsip semua pengguna");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Arsip ini akan semua pengguna kembali cocok dengan kriteria yang dipilih! Apakah Anda yakin?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Nonaktifkan semua pengguna");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Hal ini akan menonaktifkan semua pengguna kembali cocok dengan kriteria yang dipilih! Apakah Anda yakin?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Toggle status");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","3 bulan terakhir");//Last 3 months
?>