<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Công cụ quản trị");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Tên đăng nhập mới");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Chọn người dùng thay đổi đăng nhập cho");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Thay đổi thông tin đăng nhập");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Một người sử dụng với thông tin đăng nhập này đã tồn tại");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Hoạt động thành công nhưng các bảng sau đây có thể không được cập nhật");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Bài học toàn cầu cài đặt");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL giao diện");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","Lệnh SQL");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Hàng trong bộ");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","hàng bị ảnh hưởng");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Tập hợp rỗng");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Số lượng lớn hoàn thành bài học và các khóa học");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Thiết lập khóa học bài học người dùng");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll các khóa học");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Thực thể loại");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Thực thể nhập cảnh");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Chọn một mục");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Chọn một loại giao");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll người dùng");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Hoạt động này sẽ unenroll tất cả người dùng là một phần của thực thể này từ tất cả các khóa học của mình. Bạn có chắc chắn?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Thể loại báo cáo");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Chọn thể loại");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Hiển thị không đầy đủ các khóa học");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Hoàn thành từ");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","hoàn thành");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Hiển thị các khóa học không hoạt động");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Mục lịch sử");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Idle người dùng");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Lần hành động");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Cho người dùng nhàn rỗi từ");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Lưu trữ tất cả người dùng");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","lưu trữ này sẽ tất cả người dùng trả lại phù hợp với các tiêu chí lựa chọn! Bạn có chắc chắn?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Tắt tất cả người dùng");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Điều này sẽ tắt tất cả người dùng trả lại phù hợp với các tiêu chí lựa chọn! Bạn có chắc chắn?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Chuyển đổi trạng thái");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Lần 3 tháng");//Last 3 months
?>