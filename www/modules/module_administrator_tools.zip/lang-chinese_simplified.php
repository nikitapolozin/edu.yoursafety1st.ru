<?php
define("_MODULE_ADMINISTRATOR_TOOLS","管理员工具");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","新的登录名");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","选择用户更改登录名");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","更改登录");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","具有此登录用户已存在");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","操作成功完成，但下表无法更新");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","全球课设置");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL接口");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL命令");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","在集中的行");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","查询行");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","行受影响");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","空集");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","散装完整的经验教训和课程");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","套餐用户的教训");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll课程");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","实体类型");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","实体条目");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","选择一个项目");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","选择一个任务类型");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll用户");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","此操作将unenroll所有用户都是这个从它的所有课程实体的一部分。你肯定吗？");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","分类报告");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","选择类别");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","显示不完整的课程");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","完成了从");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","完成的");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","显示无效的课程");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","历史条目");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","空闲用户");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","最后行动");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","显示用户空闲自");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","存档所有用户");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","这将封存所有用户返回匹配选定的标准！你肯定吗？");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","停用所有用户");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","这将关闭所有用户返回匹配选定的标准！你肯定吗？");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","切换状态");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","过去3个月");//Last 3 months
?>