<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrator verktøy");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Nytt påloggingsnavn");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Velg bruker for å endre påloggingsinformasjonen for");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Endre login");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","En bruker med dette brukernavnet finnes allerede");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operasjonen er fullført men følgende tabeller kunne ikke oppdateres");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Global leksjon innstillinger");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL-grensesnitt");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL kommando");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","P sett");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","rader påvirket");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Tomme sett");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Bulk komplett leksjoner og kurs");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Satt kurs leksjon brukere");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll kurs");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Entity type");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entity oppføring");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Velg en oppføring");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Velg et oppdrag type");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll brukere");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Denne operasjonen vil unenroll alle brukere som er en del av denne enheten fra alle sine kurs. Er du sikker?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategori rapporter");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Velg kategori");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Vis Ufullstendig kurs");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Fullført fra");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","ferdigstilt til");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Vis inaktive kurs");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Historisk oppføring");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Idle brukere");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Siste handling");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Vis brukere inaktiv siden");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arkivere alle brukere");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Dette vil arkivere alle brukere returnerte passer til den valgte kriteriene! Er du sikker?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Deaktivere alle brukere");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Dette vil deaktivere alle brukere returnerte passer til den valgte kriteriene! Er du sikker?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Toggle status");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Siste 3 måneder");//Last 3 months
?>