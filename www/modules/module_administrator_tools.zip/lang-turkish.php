<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Yönetici araçları");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Yeni bir giriş adı");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Seçmek kullanıcı için giriş değiştirmek için");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Değiştirmek giriş");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","bu isime sahip bir kullanıcı zaten var");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operasyon ama başarıyla tamamlandı aşağıdaki tablolarda güncellenen olamazdı");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Küresel ders ayarları");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL arayüzü");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL komutu");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Satırlar set");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Sorgu Tamam");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","etkilenen satır");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Boş küme");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","dersler ve kurslar tam Dökme");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Set ders ders kullanıcılar");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll içerisinde");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Varlık türü");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Varlık giriş");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Bir giriş seçin");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","atama türü seçin");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll kullanıcılar");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Bu operasyonun kendi içerisinde tüm bu varlığın parçası olan tüm kullanıcılar unenroll olacaktır. Emin misiniz?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategori raporları");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Kategori Seçin");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Göstermek Eksik içerisinde");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","dan Tamamlandı");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","tamamladı");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Göstermek inaktif içerisinde");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Tarihi girdi");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Idle users");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Son eylemi");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Göstermek kullanıcıları bu yana boşta");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arşiv tüm kullanıcılar");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Bu olacak arşiv tüm kullanıcılar seçilen kriterlere uygun döndü! Emin misiniz?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Tüm kullanıcılar kapat");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Bu tüm kullanıcılar seçilen kriterlere uyan döndü deaktive edecektir! Emin misiniz?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Geçiş durumu");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Son 3 ay");//Last 3 months
?>