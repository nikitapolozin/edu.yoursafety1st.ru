<?php
define("_MODULE_ADMINISTRATOR_TOOLS","管理者ツール");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","新しいログイン名");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","を選択し、ユーザはログインを変更する");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","変更ログイン");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","このログイン情報を持つユーザーが既に存在して");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","操作は正常に完了した以下の表を更新できませんでした");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","グローバルレッスンの設定");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQLインタフェース");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQLコマンド");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","行セット内の");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","クエリは、[OK]を");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","影響を受ける行");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","空集合");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","レッスンやコースを完了バルク");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","セットコースレッスンユーザー");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","登録解除コース");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","エンティティタイプ");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","エンティティのエントリ");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","エントリを選択します");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","課題の種類を選択します。");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","登録解除ユーザー");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","この操作は、そのコースのすべてからこのエンティティの一部であるすべてのユーザを登録解除されます。あなたはよろしいですか？");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","カテゴリには、レポート");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","カテゴリーを選択");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","表示不完全なコース");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","から完成");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","に完了");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","地図を非アクティブコース");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","歴史的なエントリ");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","アイドルユーザー");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","最後のアクション");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","表示ユーザーからアイドル状態の");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","アーカイブのすべてのユーザー");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","このアーカイブされますすべてのユーザーが選択した条件に一致する返される！あなたはよろしいですか？");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","すべてのユーザーを無効にする");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","これは、すべてのユーザーが選択した条件に一致する返さ無効になります！あなたはよろしいですか？");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","トグルの状態");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","過去3ヶ月");//Last 3 months
?>