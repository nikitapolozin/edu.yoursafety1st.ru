<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrador de herramientas");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Nueva entrada nombre");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Seleccione el usuario para cambiar de inicio de sesión");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Cambio entrada");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Un usuario con este inicio de sesión ya existe");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","La operación se realizó con éxito, pero las tablas siguientes no se pudieron actualizar");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","La configuración global lección");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL interfaz");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","Comando SQL");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Las filas en el conjunto");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","filas afectadas");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Conjunto vacío");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","A granel completa lecciones y cursos");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Establecer los usuarios del curso lección");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Dar de baja a los cursos");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Tipo de entidad");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entidad entrada");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Seleccione una entrada");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Seleccione un tipo de asignación");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Dar de baja a los usuarios");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Esta operación va a dar de baja a todos los usuarios que forman parte de esta entidad de todos sus cursos. ¿Estás seguro?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Categoría informes");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Seleccione la categoría");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Mostrar incompleta cursos");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Completado de");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","completado a");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Mostrar inactivos cursos");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Histórico entrada");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Inactivo usuarios");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Última acción");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Mostrar usuarios inactivo desde");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Archivo de todos los usuarios");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Este archivo se devuelve todos los usuarios coinciden con los criterios seleccionados! ¿Estás seguro?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Desactivar todos los usuarios");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Esto desactivará todos los usuarios regresó a juego el criterio de búsqueda! ¿Estás seguro?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Activar el estado");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Últimos 3 meses");//Last 3 months
?>