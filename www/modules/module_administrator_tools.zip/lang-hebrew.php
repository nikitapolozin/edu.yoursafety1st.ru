<?php
define("_MODULE_ADMINISTRATOR_TOOLS","מנהל כלים");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","שם התחברות חדש");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","המשתמש בחר לשנות את הכניסה ל");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","שינוי פרטי ההתחברות");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","משתמש בשם זה כבר קיים");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","מבצע הושלמה בהצלחה אך בטבלאות הבאות לא יכול להיות מעודכן");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","הלקח הגדרות גלובל");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL הממשק");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL הפקודה");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","שורות להגדיר");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","השורות המושפעות");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","הקבוצה הריקה");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","גורפת להשלים שיעורים וקורסים");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","הלקח הגדר כמובן משתמשים");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll קורסים");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","סוג יישות");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","ישות רשומה");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","בחר ערך");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","בחר סוג המשימה");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll משתמשים");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","פעולה זו תמחק unenroll כל המשתמשים, כי הם חלק של הישות הזו מכל הקורסים שלה. האם אתה בטוח?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","קטגוריה דוחות");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","בחר קטגוריה");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","הצג קורסים Incomplete");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","הושלם מ");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","השלים את");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","הצג קורסים פעיל");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","ההיסטורי ערך");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","המתנה משתמשים");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","פעולה אחרונה");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","המשתמשים הצג סרק מאז");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","ארכיון כל המשתמשים");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","זה הארכיון יהיה כל המשתמשים חזר תואמות את הקריטריונים שנבחרו! האם אתה בטוח?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","לבטל את כל המשתמשים");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","זה יהיה לבטל את כל המשתמשים חזר תואמות את הקריטריונים שנבחרו! האם אתה בטוח?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","החלף מצב");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","3 חודשים אחרונים");//Last 3 months
?>