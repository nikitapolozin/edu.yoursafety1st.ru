<?php
define("_MODULE_ADMINISTRATOR_TOOLS","مدير أدوات");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","اسم جديد لتسجيل الدخول");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","حدد المستخدم لتغيير لتسجيل الدخول");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","تغيير تسجيل الدخول");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","مستخدم تسجيل الدخول مع هذا موجود بالفعل");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","استكملت العملية بنجاح ولكن لا يمكن تحديث الجداول التالية");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","إعدادات الدرس العالمي");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","مزود اجهة");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","مزود الأمر");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","الصفوف في مجموعة");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","الاستعلام موافق");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","الصفوف المتأثرة");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","مجموعة فارغة");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","معظم استكمال الدروس والدورات");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","للمستخدمين تعيين مسار الدرس");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","المقررات Unenroll");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","نوع الكيان");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","الكيان دخول");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","حدد إدخالا");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","حدد نوع الاحالة");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","شاهد Unenroll");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","وهذه العملية unenroll كافة المستخدمين التي هي جزء من هذا الكيان من كل دوراته. هل أنت متأكد؟");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","فئة التقارير");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","حدد فئة");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","عرض المقررات كاملة");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","الانتهاء من");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","استكملت ل");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","المقررات إظهار نشط");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","دخول التاريخية");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","المستخدمين الخمول");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","آخر عمل");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","عرض المستخدمين عاطلة منذ");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","الأرشيف جميع المستخدمين");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","هذا الأرشيف وعاد جميع المستخدمين المطابقة للمعايير المحددة! هل أنت متأكد؟");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","تعطيل جميع المستخدمين");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","وهذا تعطيل جميع المستخدمين عاد المطابقة للمعايير المحددة! هل أنت متأكد؟");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","تبديل حالة");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","آخر 3 أشهر");//Last 3 months
?>