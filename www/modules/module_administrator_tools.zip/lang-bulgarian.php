<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Администратор инструменти");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Нови потребителско име");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Изберете потребителя да променя вход за");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Промяна вход");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Потребител с такова име вече съществува");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Операцията приключи успешно, но таблиците по-долу не може да се актуализира");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Глобални настройки урок");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL интерфейс");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL команда");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Редът в комплект");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Запитване OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","засегнати редове");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Празни, определени");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Насипни пълна уроци и курсове");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Задайте потребители курс урок");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll курсове");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Субект тип");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Субект влизане");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Изберете запис");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Изберете тип работа");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll потребители");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Тази операция ще unenroll всички потребители, които са част от тази организация, от всички свои курсове. Сигурни ли сте?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Категория доклади");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Изберете категория");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Покажи Непълно курсове");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Завършен от");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","допълнени, за да");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Показване на неактивни курсове");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Исторически влизане");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Готовност на потребителите");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Последно действие");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Показване на празен ход, тъй като потребителите");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Архив на всички потребители");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Това ще архив на всички потребители върнати, отговаряща на избраните критерии! Сигурни ли сте?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Деактивирайте всички потребители");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Това ще деактивира всички потребители върнати, отговаряща на избраните критерии! Сигурни ли сте?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Превключване на статут");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Последните 3 месеца");//Last 3 months
?>