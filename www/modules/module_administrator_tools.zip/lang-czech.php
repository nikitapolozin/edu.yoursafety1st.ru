<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrátorských nástrojů");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Nové přihlašovací jméno");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Vyberte uživatele ke změně přihlašovacích pro");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Změna přihlašovací údaje");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Uživatel s tímto přihlášení již existuje");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operace byla úspěšně dokončena, ale v následujících tabulkách nelze aktualizovat");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Globální nastavení lekce");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL rozhraní");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL příkaz");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Řádků v souboru");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Dotaz na tlačítko OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","postižených řádky");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Prázdná množina");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Hromadné kompletní lekce a kurzy");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Nastavení uživatelů během lekce");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll kurzy");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Entity typu");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Účetní jednotka vstupu");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Vyberte položku");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Vyberte typ přiřazení");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll uživatelů");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Tato operace bude unenroll všichni uživatelé, které jsou součástí této společnosti ze všech svých kurzů. Jste si jisti?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategorie zpráv");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Zvolte kategorii");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Zobrazit Neúplné kurzy");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Dokončeny z");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","dokončeny podle");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Zobrazit neaktivní kurzy");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Historické vstupu");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Nečinnosti uživatele");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Poslední akce");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Zobrazit uživatele nečinný, neboť");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Archiv všech uživatelů");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","To bude archivovat všechny uživatele vrátil vyhovující zvoleným kritériím! Jste si jisti?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Deaktivovat všechny uživatele");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","To bude deaktivovat všechny uživatele vrátil vyhovující zvoleným kritériím! Jste si jisti?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Přepnout stav");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Poslední 3 měsíce");//Last 3 months
?>