<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Hallintatyökalu");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Uusi kirjautuminen nimi");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Valitse käyttäjä voi vaihtaa kirjautumisen");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Change login");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Käyttäjä tällä käyttäjänimellä jo olemassa");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operaatio suoritettu onnistuneesti, mutta seuraavat taulukot ei voitu päivittää");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Global oppitunti asetukset");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL-liitäntä");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL-komento");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Rivit asetettu");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","riviä vaikuttaa");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Tyhjä joukko");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Bulk täydellinen oppitunteja ja kursseja");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Aseta kurssi oppitunti käyttäjille");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll kurssit");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Entity tyyppi");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entity merkintä");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Valitse merkintä");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Valitse tehtävän tyyppi");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll käyttäjää");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Tämä toimenpide unenroll kaikille käyttäjille, jotka ovat osa tätä kokonaisuutta kaikki sen kurssit. Oletko varma?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Luokka raportit");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Valitse luokka");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Näytä Puutteellinen kurssit");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Valmistuneen");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","päätökseen");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Näytä ei-aktiiviset kurssit");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Historiallinen merkintä");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Idle käyttäjää");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Viimeisin toiminta");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Näytä käyttäjän käyttämättömänä vuodesta");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arkisto kaikki käyttäjät");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Tämä arkistoida kaikki käyttäjien palasi vastaavat valitut kriteerit! Oletko varma?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Poista kaikki käyttäjät");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Tämä poistaa kaikki käyttäjät palasi vastaavat valitut kriteerit! Oletko varma?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Vaihda tila");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Viime 3 kuukautta");//Last 3 months
?>