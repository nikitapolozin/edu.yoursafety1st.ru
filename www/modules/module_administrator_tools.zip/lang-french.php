<?php
define("_MODULE_ADMINISTRATOR_TOOLS","outils d&#39;administration");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Nouveau nom de connexion");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Sélectionnez l&#39;utilisateur à changer de connexion pour");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Changer connexion");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Un utilisateur avec ce nom existe déjà");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Opération réussie, mais les tableaux suivants n&#39;ont pas pu être mis à jour");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","paramètres leçon mondial");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","interface SQL");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","commande SQL");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Rangées dans la série");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","lignes affectées");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Empty set");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","En vrac complète des cours et");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","les utilisateurs du kit leçon de cours");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","cours désinscrire");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","type d&#39;entité");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entité d&#39;entrée");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Sélectionnez une entrée");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Sélectionnez un type d&#39;affectation");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","utilisateurs désinscrire");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Cette opération sera désinscrire tous les utilisateurs qui font partie de cette entité de l&#39;ensemble de ses cours. Etes-vous sûr?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Catégorie rapports");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Sélectionnez une catégorie");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Montrez les cours incomplets");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Achevé de");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","rempli à");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Montrez les cours inactifs");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","entrée historique");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","L&#39;inactivité des utilisateurs");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Dernière action");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Montrer les utilisateurs ralenti depuis");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Archive tous les utilisateurs");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Cette archive sera retourné tous les utilisateurs correspondant aux critères sélectionnés! Etes-vous sûr?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Désactiver tous les utilisateurs");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Cela désactivera tous les utilisateurs étaient de retour correspondant aux critères sélectionnés! Etes-vous sûr?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","basculer le statut");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","3 derniers mois");//Last 3 months
?>