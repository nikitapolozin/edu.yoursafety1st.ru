<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administratorius įrankiai");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Naujas prisijungimo vardas");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Pasirinkite vartotojo pakeisti prisijungimo");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Keisti prisijungimo");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Su pasirinktu prisijungimo vardu vartotojas jau yra");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operacija sėkmingai, tačiau šios lentelės negali būti atnaujintas");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Pasaulinis pamoka nustatymus");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL sąsaja");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL komandą");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Eilutes nustatyti");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Užklausa Gerai");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","eilučių poveikį");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Tuščia nustatyti");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Tūrinės pilnas pamokos ir kursai");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Nustatyti kursas pamokų vartotojai");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll kursai");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Subjekto tipas");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Subjektas įrašas");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Pasirinkite įrašo");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Pasirinkite užduoties tipas");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll vartotojai");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Ši operacija bus unenroll visiems vartotojams, kurie yra dalis iš visų savo kursai subjektas. Ar tikrai?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategorija ataskaitos");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Pasirinkite kategoriją");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Rodyti Neišsami kursai");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Įgyvendintas iš");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","užpildytas");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Rodyti neveikiančią kursai");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Istorinis įrašas");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Neveikos vartotojai");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Paskutinis veiksmas");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Rodyti vartotojams eigos, nes");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Archyvas visi vartotojai");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Tai archyvas visų vartotojų grįžo atitinkančių pasirinktus kriterijus! Ar tikrai?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Išjungti visas vartotojų");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Tai bus i ¹ jungti visas vartotojų grįžo atitinkančių pasirinktus kriterijus! Ar tikrai?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Perjungti statusas");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Paskutiniai 3 mėnesiai");//Last 3 months
?>