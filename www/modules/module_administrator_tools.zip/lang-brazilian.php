<?php
define("_MODULE_ADMINISTRATOR_TOOLS","ferramentas de administrador");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Novo nome de login");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Selecionar usuário a mudar de login para");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Alterar login");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Um usuário com esse nome já existe");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operação concluída com êxito, mas as tabelas a seguir não pôde ser atualizado");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Global configurações de lição");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","interface SQL");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","comando SQL");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Filas em conjunto");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","linhas afetadas");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Conjunto vazio");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Massa completa aulas e cursos");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Definir lição usuários curso");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","cursos Unenroll");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","tipo de entidade");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","entrada Entidade");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Selecione uma entrada");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Selecione um tipo de atribuição");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","usuários Unenroll");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Esta operação irá unenroll todos os usuários que fazem parte desta entidade de todos os seus cursos. Você tem certeza?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Categoria relatórios");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Selecionar categoria");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Mostrar os cursos incompletos");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Concluído");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","preenchido para");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","cursos Show inativos");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","entrada Histórico");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Usuários inativos");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Última acção");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Mostrar utilizadores inativo desde");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arquivar todos os usuários");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Este arquivo será devolvido todos os usuários que correspondem aos critérios selecionados! Você tem certeza?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Desative todos os usuários");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Isto irá desativar todos os usuários retornaram combinando os critérios selecionados! Você tem certeza?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","status Toggle");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Últimos 3 meses");//Last 3 months
?>