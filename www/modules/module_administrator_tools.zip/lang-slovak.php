<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrátorských nástrojov");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Nové prihlasovacie meno");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Vyberte užívateľa k zmene prihlasovacích pre");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Zmena prihlasovacie údaje");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Užívateľ s týmto prihlásenie už existuje");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operácia bola úspešne dokončená, ale v nasledujúcich tabuľkách nemožno aktualizovať");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Globálne nastavenia lekcie");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL rozhranie");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL príkaz");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Riadkov v súbore");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Dotaz na tlačidlo OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","postihnutých riadky");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Prázdna množina");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Hromadné kompletné lekcie a kurzy");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Nastavenie užívateľov počas lekcie");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll kurzy");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Entity typu");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Účtovná jednotka vstupu");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Vyberte položku");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Vyberte typ priradenie");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll užívateľov");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Táto operácia bude unenroll všetci užívatelia, ktoré sú súčasťou tejto spoločnosti zo všetkých svojich kurzov. Ste si istí?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategórie správ");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Zvoľte kategóriu");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Zobraziť Neúplné kurzy");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Dokončené z");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","dokončené podľa");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Zobraziť neaktívne kurzy");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Historické vstupu");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Nečinnosti užívateľa");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Posledná akcia");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Zobraziť používateľa nečinný, pretože");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Archív všetkých užívateľov");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","To bude archivovať všetkých užívateľov vrátil vyhovujúce zvoleným kritériám! Ste si istí?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Deaktivovať všetkých užívateľov");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","To bude deaktivovať všetkých užívateľov vrátil vyhovujúce zvoleným kritériám! Ste si istí?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Prepnúť stav");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Posledné 3 mesiace");//Last 3 months
?>