<?php
define("_MODULE_ADMINISTRATOR_TOOLS","관리자 도구");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","새 로그인 이름");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","선택 사용자가 로그인을 변경하려면");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","변경 로그인");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","이 로그인과 사용자가 이미 존재");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","수술은 성공적으로 완료 다음과 같은 테이블을 업데이트할 수 없습니다");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","글로벌 교훈 설정");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL 데이터 인터페이스");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL 명령");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","행 집합에");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","검색어가 좋아");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","영향을받는 행");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","공집합");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","수업 및 코스를 완료 대량");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","설정 과정 수업 사용자");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll 코스");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","법인 유형");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","엔티티 항목");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","항목을 선택");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","할당 유형을 선택");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll 사용자");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","이 작업은 모든 과목에서 해당 엔티티에 속하는 모든 사용자에게 unenroll 것입니다. 당신은 확실한가요?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","카테고리 보고서");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","선택 카테고리");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","보기 불완전 코스");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","부터 완료");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","에 완료");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","비활성 코스");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","역사적 항목");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","유휴 사용자");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","마지막 작업");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","표시 사용자 이후 유휴");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","보관 모든 사용자");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","이됩니다 아카이브 모든 사용자가 선택한 기준과 일치하는 돌아왔다! 당신은 확실한가요?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","모든 사용자를 비활성화");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","이것은 모든 사용자가 선택한 기준과 일치하는 반환 비활성화 것입니다! 당신은 확실한가요?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","전환 상태");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","최근 3 개월");//Last 3 months
?>