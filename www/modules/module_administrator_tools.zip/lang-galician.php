<?php
define("_MODULE_ADMINISTRATOR_TOOLS","ferramentas de administrador");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Novo nome de usuario");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Seleccionar usuario a cambiar de rexistro para");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Cambiar login");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Un usuario con ese nome xa existe");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operación finalizou con éxito, pero as táboas a continuación non puido ser actualizado");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Global opcións de lección");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","interface SQL");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","comando SQL");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Filas en conxunto");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","liñas afectadas");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Conxunto baleiro");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Masa completa clases e cursos");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Definir lección usuarios curso");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","cursos Unenroll");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","tipo de entidade");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","entrada Entidade");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Seleccione unha entrada");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Seleccione un tipo de asignación");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","usuarios Unenroll");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Esta operación pode unenroll todos os usuarios que forman parte desta entidade de todos os seus cursos. Está seguro?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Categoría informes");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Seleccionar categoría");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Amosar os cursos incompletos");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Feito");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","cuberto para");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","cursos Show inactivos");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","entrada Historial");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Usuarios inactivos");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Última acción");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Mostrar usuarios inactivo desde");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arquivar todos os usuarios");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Este ficheiro será devolto todos os usuarios que corresponden aos criterios seleccionados! Está seguro?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Desactivar todos os usuarios");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Isto desactivar todos os usuarios retornaron combinando os criterios seleccionados! Está seguro?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","status Toggle");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Últimos 3 meses");//Last 3 months
?>