<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrator tools");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Nieuwe loginnaam");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Selecteer de gebruiker in te loggen veranderen");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Verander login");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Een gebruiker met deze login bestaat al");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Bewerking is voltooid, maar de volgende tabellen kan niet worden bijgewerkt");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Global les instellingen");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL-interface");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL-opdracht");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Rijen in te stellen");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query op OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","getroffen rijen");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Lege verzameling");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Bulk complete lessen en cursussen");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Ingestelde koers les gebruikers");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Uitschrijven cursussen");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Type entiteit");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entiteit item");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Selecteer een item");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Selecteer een type opdracht");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Uitschrijven gebruikers");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Deze operatie zal uitschrijven voor alle gebruikers die deel uitmaken van deze entiteit van al haar cursussen. Ben je zeker?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Categorie rapporten");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Selecteer een categorie");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Toon Onvolledige cursussen");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Afgesloten van de");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","afgerond naar");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Toon inactief cursussen");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Historische vermelding");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Nutteloze gebruikers");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Laatste actie");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Toon gebruikers stationair sinds");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Archief voor alle gebruikers");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Dit zal archiveren alle gebruikers weer die overeenkomen met de gekozen criteria! Ben je zeker?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Deactiveren alle gebruikers");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Dit zal deactiveren alle gebruikers weer die overeenkomen met de gekozen criteria! Ben je zeker?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Toggle status");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Laatste 3 maanden");//Last 3 months
?>