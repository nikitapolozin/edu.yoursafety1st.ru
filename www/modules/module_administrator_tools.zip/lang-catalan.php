<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrador d&#39;eines");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Nova entrada nom");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Seleccioneu l&#39;usuari per canviar d&#39;inici de sessió");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Canvi entrada");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Un usuari amb aquest inici de sessió ja existeix");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","L&#39;operació es va realitzar amb èxit, però les taules següents no es van poder actualitzar");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","La configuració global lliçó");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL interfície");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","Comando SQL");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Les files en el conjunt");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","files afectades");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Conjunt buit");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","A granel completa lliçons i cursos");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Establir els usuaris del curs lliçó");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Donar de baixa els cursos");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Tipus d&#39;entitat");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entitat entrada");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Seleccioneu una entrada");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Seleccioneu un tipus d&#39;assignació");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Donar de baixa els usuaris");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Aquesta operació donarà de baixa a tots els usuaris que formen part d&#39;aquesta entitat de tots els seus cursos. Estàs segur?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Categoria informes");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Seleccioneu la categoria");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Mostra incompleta cursos");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Completat de");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","completat a");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Mostra inactius cursos");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Històric entrada");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Inactiu usuaris");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Darrera acció");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Mostra usuaris inactiu des");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arxiu de tots els usuaris");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Aquest fitxer es retorna tots els usuaris coincideixen amb els criteris seleccionats! Estàs segur?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Desactivar tots els usuaris");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Això desactivarà tots els usuaris tornar a joc el criteri de cerca! Estàs segur?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Activar l&#39;estat");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Darrers 3 mesos");//Last 3 months
?>