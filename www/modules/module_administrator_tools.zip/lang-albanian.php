<?php
define("_MODULE_ADMINISTRATOR_TOOLS","mjete Administrator");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Emri i ri hyrje me emrin përkatës");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","përdorues Zgjidh për të ndryshuar për hyrje me emrin përkatës");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","login Ndryshimi");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Një përdorues me këtë login tashmë ekziston");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operacioni përfundoi me sukses, por tabelat e mëposhtme nuk do të mund të përditësuar");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Konfigurimet e Global mësim");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","interface SQL");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","komandën SQL");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Rreshta në grup");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","rreshtave të prekur");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","vendosur Empty");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Pjesa më e madhe të plotë mësime dhe kurse");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Set mësim kurs përdoruesit");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","kurse Unenroll");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Lloji i subjektit");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","hyrje subjektit");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Zgjidh një shënim");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Përzgjidhni një lloj detyrë");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","përdoruesit Unenroll");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Ky operacion do të unenroll të gjithë përdoruesit që janë pjesë e këtij subjekti nga të gjitha kurset e saj. A jeni i sigurt?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategoria Raportet");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Zgjidhni kategori");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","kurse Show pakompletuar");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Përfunduar nga");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","përfunduar në");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","kurse Show joaktiv");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","hyrje Historike");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","përdoruesit Idle");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","veprim më të fundit");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Show përdoruesit e papunë që prej");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arkivi i të gjithë përdoruesit");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Ky arkiv do të kthehen të gjithë përdoruesit të ngjashëm me kritereve të zgjedhura! A jeni i sigurt?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Çaktivizuar të gjithë përdoruesit");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Kjo do të çaktivizuar të gjithë përdoruesit e kthyer të ngjashëm me kritereve të zgjedhura! A jeni i sigurt?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","status Toggle");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","E fundit 3 muaj");//Last 3 months
?>