<?php
define("_MODULE_ADMINISTRATOR_TOOLS","管理員工具");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","新的登錄名");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","選擇用戶更改登錄名");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","更改登錄");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","用戶使用此登錄信息已經存在");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","操作成功完成，但下表無法更新");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","全球課設置");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL接口");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL命令");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","在SET行");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","查詢行");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","行受影響");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","空集");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","散裝完整的經驗教訓和課程");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","套餐用戶的教訓");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll課程");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","實體類型");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","實體條目");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","選擇一個項目");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","選擇一個任務類型");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll用戶");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","此操作將 unenroll所有用戶的一部分，從這個實體的所有課程。你肯定嗎？");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","分類報告");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","選擇類別");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","顯示不完整的課程");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","完成了從");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","完成的");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","顯示無效的課程");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","歷史條目");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","空閒用戶");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","最後行動");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","顯示用戶空閒自");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","存檔所有用戶");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","這將封存所有用戶返回匹配選定的標準！你肯定嗎？");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","停用所有用戶");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","這將關閉所有用戶返回匹配選定的標準！你肯定嗎？");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","切換狀態");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","過去 3個月");//Last 3 months
?>