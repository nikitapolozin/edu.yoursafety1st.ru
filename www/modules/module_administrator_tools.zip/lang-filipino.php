<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Tagapangasiwa ng mga kasangkapan");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Bagong login name");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Pumili ng user na baguhin login para");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Baguhin ang login");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Ang isang user na may login na ito ay umiiral na");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operation Matagumpay na natapos ngunit ang mga sumusunod na talahanayan ay hindi ma-update");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Global lesson setting");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL interface");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL command");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Hilera sa set");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","hilera apektado");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Walang laman set");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Bulk kumpletong mga aralin at mga kurso");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Itakda ang kurso lesson gumagamit");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll kurso");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Entity uri");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entity entry");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Pumili ng isang entry");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Pumili ng isang uri ng assignment");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll gumagamit");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Ang operasyon na ito ay unenroll lahat ng mga gumagamit na bahagi ng ito entity mula sa lahat ng kanyang mga kurso. Sigurado ka ba?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Category ulat");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Pumili ng kategorya");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Ipakita ang kumpletong kurso");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Natapos mula");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","nakumpleto na");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Ipakita ang mga inactive na kurso");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Historic entry");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Idle mga gumagamit");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Huling pagkilos");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Ipakita ang mga gumagamit idle dahil");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Archive lahat ng mga gumagamit");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Ito ay archive lahat ng mga gumagamit ay bumalik na tumutugma sa napiling criteria! Sigurado ka ba?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Deactivate ang lahat ng mga gumagamit");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Ito ay deactivate ang lahat ng mga gumagamit ay bumalik na tumutugma sa napiling criteria! Sigurado ka ba?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Magpalipat-lipat sa katayuan");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Huling 3 buwan");//Last 3 months
?>