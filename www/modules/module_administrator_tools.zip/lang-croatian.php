<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrator alati");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Novo ime za prijavu");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Odaberite korisnika za promjenu prijavu za");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Promijeni prijavu");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Korisnik s ovim korisničkim imenom već postoji");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operacija je uspješno dovršeno, ali sljedećim tablicama nije mogao biti ažuriran");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Globalni sat postavke");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL sučelje");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL naredba");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Reci u skup");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","redaka utjecati");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Prazni skup");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Bulk kompletan lekcije i tečajevi");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Postavite tečaj sat korisnika");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll tečajeve");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Vrsta objekta");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entitetska upis");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Izaberite unos");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Odaberite tip zadatka");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll korisnika");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Ova operacija će unenroll sve korisnike koji su dio ovog entiteta iz svih svojih tečajeva. Jeste li sigurni?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategorija izvješća");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Odaberite kategoriju");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Prikaži Nepotpuni tečajeve");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Završeni iz");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","dovršen do");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Prikaži neaktivne tečajeve");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Povijesni ulazak");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Idle korisnika");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Posljednja akcija");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Prikaži korisnike mirovanja od");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arhiva sve korisnike");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","To će arhiva svih korisnika vratio odgovara odabranim kriterijima! Jeste li sigurni?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Isključiti sve korisnike");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Ovo će isključiti sve korisnike vratio odgovara odabranim kriterijima! Jeste li sigurni?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Toggle status");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Zadnja 3 mjeseca");//Last 3 months
?>