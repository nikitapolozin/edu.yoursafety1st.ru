<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrator eszközök");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Új felhasználói nevet");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Válassza ki a felhasználónak a bejelentkezési adatokat");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Változás belépés");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","A felhasználó ezt a bejelentkezést már létezik");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Művelet sikeresen befejeződött, de a következő táblázatok nem lehet frissíteni");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Globális leckét beállítások");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL interfész");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL-parancs");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Sorok meg");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","érintett sorok");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Üres halmaz");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Tömeges teljes órák és tanfolyamok");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Állítsa kurzus lecke felhasználók");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll tanfolyamok");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Entitás típusa");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Entity bejegyzés");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Válasszon ki egy bejegyzést");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Válassza ki a feladat típusát");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll felhasználók");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Ez a művelet unenroll minden felhasználó, amelyek egy részét a szervezet minden annak tanfolyamok. Biztos vagy benne?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategória jelentések");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Válasszon kategóriát");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Megjelenítés Befejezetlen tanfolyamok");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Befejezve a");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","kitöltött");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Megjelenítés inaktív tanfolyamok");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Történelmi bejegyzés");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Idle felhasználók");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Utolsó akció");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Megjelenítés felhasználó tétlen, mivel");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Archívum összes felhasználó");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Ez archiválja valamennyi felhasználó visszatért felel meg a kiválasztott kritériumokat! Biztos vagy benne?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Kikapcsolhatjuk az összes felhasználó");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Ez kikapcsolja az összes felhasználó visszatért felel meg a kiválasztott kritériumokat! Biztos vagy benne?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Toggle állapota");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Utolsó 3 hónap");//Last 3 months
?>