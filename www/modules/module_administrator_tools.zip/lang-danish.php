<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrator værktøjer");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Nye login-navn");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Vælg brugeren mulighed for at ændre login til");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Ændre login");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","En bruger med dette login findes allerede");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Operation fuldført, men følgende tabeller kan ikke opdateres");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Globale lektion indstillinger");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL-grænseflade");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL-kommando");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Rækker i sæt");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Forespørgsel OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","påvirket rækker");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Tomme mængde");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Bulk komplet lektioner og kurser");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Sætter kursen lektion brugere");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll kurser");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Enhed type");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Enhed ind");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Vælg en post");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Vælg en opgave type");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll brugere");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Denne transaktion vil unenroll alle brugere, der er en del af denne enhed fra alle sine kurser. Er du sikker?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategori rapporter");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Vælg kategori");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Vis Ufuldstændig kurser");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Afsluttet fra");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","ført til ende til");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Vis inaktive kurser");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Historisk indrejse");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Tomgang brugere");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Sidste handling");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Vis brugere tomgang siden");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arkivere alle brugere");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Dette vil arkivere alle brugere returneret matcher de valgte kriterier! Er du sikker?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Deaktivere alle brugere");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Dette vil deaktivere alle brugere returneret matcher de valgte kriterier! Er du sikker?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Slå status");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Sidste 3 måneder");//Last 3 months
?>