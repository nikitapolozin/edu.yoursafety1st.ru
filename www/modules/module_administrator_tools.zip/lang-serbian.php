<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Администратор Тоолс");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Ново име за пријаву");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Изаберите кориснику да промени податке за пријављивање");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Промените податке за пријављивање");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Корисник са овим именом већ постоји");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Операција је успешно довршена, али следеће табеле није могао бити ажуриран");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Глобална Лекција подешавања");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","СКЛ интерфејса");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","СКЛ наредба");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Ровс ин сет");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Куери ОК");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","редова утиче");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Празан скуп");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Групно комплетне лекције и курсеви");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Постави курс Лекција корисника");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Уненролл курсеви");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Тип објекта");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Ентитета унос");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Изаберите унос");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Изаберите тип задатка");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Уненролл корисника");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Ова операција ће уненролл све кориснике који су део овог ентитета од свих својих курсева. Јесте ли сигурни?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Категорија страница извештаја");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Изабери категорију");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Прикажи Непотпуне курсеви");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Комплетиран из");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","завршен у");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Прикажи неактивне курсеви");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Историјски унос");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Мировање корисника");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Последња акција");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Прикажи неактивне од корисника");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Архива све кориснике");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Ово ће архива све кориснике вратио се подударају изабрани критеријум! Јесте ли сигурни?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Деактивирај све кориснике");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Ово ће деактивирати све кориснике вратио се подударају изабрани критеријум! Јесте ли сигурни?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Тоггле статуса");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Последња 3 месеца");//Last 3 months
?>