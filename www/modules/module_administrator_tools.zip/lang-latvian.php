<?php
define("_MODULE_ADMINISTRATOR_TOOLS","Administrators instrumenti");//Administrator tools
define("_MODULE_ADMINISTRATOR_TOOLS_NEWLOGIN","Jaunu pieteikšanās vārdu");//New login name
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTUSERTOCHANGELOGINFOR","Izvēlieties lietotājam mainīt pieteikšanās");//Select user to change login for
define("_MODULE_ADMINISTRATOR_TOOLS_CHANGELOGIN","Mainīt login");//Change login
define("_MODULE_ADMINISTRATOR_TOOLS_USERALREADYEXISTS","Ar šo login lietotājs jau eksistē");//A user with this login already exists
define("_MODULE_ADMINISTRATOR_TOOLS_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED","Darbības veiksmīgi pabeigta, bet tabulās nevarēja atjaunināt");//Operation completed successfully but the following tables could not be updated
define("_MODULE_ADMINISTRATOR_TOOLS_GLOBALLESSONSETTINGS","Pasaules nodarbība uzstādījumi");//Global lesson settings
define("_MODULE_ADMINISTRATOR_TOOLS_SQLINTERFACE","SQL interfeisu");//SQL interface
define("_MODULE_ADMINISTRATOR_TOOLS_SQLCOMMAND","SQL komandu");//SQL command
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSINSET","Rindu, kas");//Rows in set
define("_MODULE_ADMINISTRATOR_TOOLS_QUERYOK","Query OK");//Query OK
define("_MODULE_ADMINISTRATOR_TOOLS_ROWSAFFECTED","ietekmē rindas");//rows affected
define("_MODULE_ADMINISTRATOR_TOOLS_EMPTYSET","Tukšas, kas");//Empty set
define("_MODULE_ADMINISTRATOR_TOOLS_BULKCOMPLETECOURSES","Bulk pilnīga nodarbības un kursi");//Bulk complete lessons and courses
define("_MODULE_ADMINISTRATOR_TOOLS_SETCOURSELESSONUSERSCODE","Set kurss nodarbība lietotājiem");//Set course lesson users
define("_MODULE_ADMINISTRATOR_TOOLS_UNENROLLJOBCOURSES","Unenroll kursi");//Unenroll courses
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYTYPE","Uzņēmuma veids");//Entity type
define("_MODULE_ADMINISTRATOR_TOOLS_ENTITYENTRY","Uzņēmums ierakstu");//Entity entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTANENTRY","Izvēlieties ierakstu");//Select an entry
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTASSIGNMENTTYPE","Izvēlieties uzdevumu veidu");//Select an assignment type
define("_MODULE_ADMINISTRATOR_TOOLS_REMOVECOURSESFROMUSERS","Unenroll lietotāji");//Unenroll users
define("_MODULE_ADMINISTRATOR_TOOLS_AREYOUSUREYOUWANTTOREMOVEENTITYUSERSFROMENTITYCOURSES","Šī operācija unenroll visiem lietotājiem, kas ir daļa no šīs vienības no visiem tās kursiem. Vai esat pārliecināts?");//This operation will unenroll all users that are part of this entity from all of its courses. Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_CATEGORYREPORTS","Kategorijas ziņojumi");//Category reports
define("_MODULE_ADMINISTRATOR_TOOLS_SELECTECATEGORY","Izvēlēties kategoriju");//Select category
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINCOMPLETE","Rādīt Nepabeigts kursi");//Show Incomplete courses
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDFROM","Pabeigts no");//Completed from
define("_MODULE_ADMINISTRATOR_TOOLS_COMPLETEDTO","pabeigusi");//completed to
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVECOURSES","Rādīt neaktīvo kursi");//Show inactive courses
define("_MODULE_ADMINISTRATOR_TOOLS_HISTORICENTRY","Vēsturiska ierakstu");//Historic entry
define("_MODULE_ADMINISTRATOR_TOOLS_IDLEUSERS","Tukšgaitas lietotājiem");//Idle users
define("_MODULE_ADMINISTRATOR_TOOLS_LASTACTION","Pēdējās darbības");//Last action
define("_MODULE_ADMINISTRATOR_TOOLS_SHOWINACTIVEUSERSSINCE","Parādīt lietotājus dīkstāvē, jo");//Show users idle since
define("_MODULE_ADMINISTRATOR_TOOLS_ARCHIVEALLUSERS","Arhīvs visiem lietotājiem");//Archive all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLARCHIVEALLUSERSAREYOUSURE","Tas arhīvs visiem lietotājiem atgriezās kas atbilst izvēlētajiem kritērijiem! Vai esat pārliecināts?");//This will archive all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_DEACTIVATEALLUSERS","Deaktivizētu visas lietotāju");//Deactivate all users
define("_MODULE_ADMINISTRATOR_TOOLS_THISWILLDEACTIVATEALLUSERSAREYOUSURE","Tas deaktivizētu visas lietotāju atgriezās kas atbilst izvēlētajiem kritērijiem! Vai esat pārliecināts?");//This will deactivate all users returned matching the selected criteria! Are you sure?
define("_MODULE_ADMINISTRATOR_TOOLS_TOGGLESTATUS","Pārslēgt statusa");//Toggle status
define("_MODULE_ADMINISTRATOR_TOOLS_LAST3MONTHS","Pēdējo 3 mēnešu laikā");//Last 3 months
?>