<?php
define("_MODULE_SECURITY_MODULESECURITY", "Άρθρωμα ασφάλειας");
define("_MODULE_SECURITY_LOCALISSUE", "Local security issue");
define("_MODULE_SECURITY_INSTALLATIONFOLDERSTILLEXISTS", "Installation folder <b>www/install</b> still exists");
define("_MODULE_SECURITY_MAGICQUOTESGPCISON", "php ini setting <b>magic_quotes_gpc<b> is ON");
define("_MODULE_SECURITY_DEFAULTACCOUNTSSTILLEXIST", "Default accounts with default credentials, <b>student/student</b> and <b>professor/professor</b> still exist");
?>
